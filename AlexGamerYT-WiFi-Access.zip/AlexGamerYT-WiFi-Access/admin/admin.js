const $=s=>document.querySelector(s);
firebase.initializeApp(FIREBASE_CONFIG);const auth=firebase.auth(),db=firebase.firestore();let data=[];
const fmt=d=>d?d.toDate().toLocaleString("es-ES"):"";
$("#in").onclick=()=>auth.signInWithEmailAndPassword($("#em").value,$("#pa").value).catch(()=>$("#err").textContent="Credenciales incorrectas.");
$("#out").onclick=()=>auth.signOut();
auth.onAuthStateChanged(u=>{$("#login").classList.toggle("hide",!!u);$("#panel").classList.toggle("hide",!u);if(u)load()});
async function load(){try{const s=await db.doc("settings/main").get();const c=s.data()||{};
 $("#c1").value=c.ssid||"iPhone de Alex";$("#c2").value=c.password||"";$("#c3").value=c.youtube||"https://youtube.com/@alexgameryt-0";$("#c4").value=c.seconds??5;
 const q=await db.collection("visits").orderBy("createdAt","desc").get();data=q.docs.map(d=>({id:d.id,...d.data()}));
 $("#n1").textContent=data.length;$("#n2").textContent=data.filter(v=>v.youtube).length;$("#n3").textContent=data.filter(v=>v.completed).length;
 const tb=$("#rows");tb.textContent="";data.forEach(v=>{const tr=tb.insertRow();[fmt(v.createdAt),v.name,v.youtube?"Sí":"No",v.completed?"Sí":"No"].forEach(t=>tr.insertCell().textContent=t)})
}catch(e){$("#ok").textContent="Sin permisos: revisa que tu correo coincida con firestore.rules."}}
$("#save").onclick=async()=>{await db.doc("settings/main").set({ssid:$("#c1").value.trim(),password:$("#c2").value,youtube:$("#c3").value.trim(),seconds:Number($("#c4").value)||0});$("#ok").textContent="Guardado."};
$("#del").onclick=async()=>{if(!confirm("¿Borrar todos los registros? No se puede deshacer."))return;
 for(let i=0;i<data.length;i+=400){const b=db.batch();data.slice(i,i+400).forEach(v=>b.delete(db.collection("visits").doc(v.id)));await b.commit()}load()};
$("#csv").onclick=()=>{const e=t=>{t=String(t??"");if(/^[=+\-@]/.test(t))t="'"+t;return '"'+t.replace(/"/g,'""')+'"'};
 const csv="Fecha,Nombre,YouTube,Completado\n"+data.map(v=>[fmt(v.createdAt),v.name,v.youtube,v.completed].map(e).join(",")).join("\n");
 const a=document.createElement("a");a.href=URL.createObjectURL(new Blob(["\ufeff"+csv],{type:"text/csv"}));a.download="visitas.csv";a.click()};
