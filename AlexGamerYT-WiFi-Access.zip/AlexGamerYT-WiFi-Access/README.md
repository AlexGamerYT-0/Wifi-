# AlexGamerYT Wi-Fi Access
Portal estático (HTML/CSS/JS) + Firebase (Firestore y Auth). Gratis con GitHub Pages y el plan Spark.

## 1. Firebase
1. En https://console.firebase.google.com crea un proyecto.
2. **Compilación › Firestore Database**: crear base de datos (modo producción).
3. **Compilación › Authentication › Método de acceso**: activa *Correo/contraseña* y en *Usuarios* crea tu cuenta de administrador.
4. **Configuración del proyecto › Tus apps › Web (</>)**: copia la configuración en `firebase/config.js`.
5. En `firebase/firestore.rules` cambia `TU_CORREO_ADMIN@gmail.com` por tu correo y pega el contenido en **Firestore › Reglas › Publicar**.
6. En **Authentication › Configuración › Dominios autorizados** añade `TUUSUARIO.github.io`.

## 2. Publicar en GitHub Pages
Sube la carpeta a un repositorio nuevo › **Settings › Pages › Deploy from branch › main / root**.
Web: `https://TUUSUARIO.github.io/REPO/` · Admin: `.../admin/`

## 3. Primer uso
Entra en `/admin/`, inicia sesión, rellena los ajustes y pulsa **Guardar** (crea el documento `settings/main`).

## Notas de seguridad
- La contraseña de admin vive en Firebase Auth, no en el código. Los ajustes del Wi-Fi son de lectura pública (la web necesita leerlos), así que alguien técnico podría verlos sin pasar por YouTube. El flujo es cortesía, no una barrera.
- iOS no permite conectar al Wi-Fi ni abrir ajustes desde Safari: se muestran instrucciones manuales.
- El contador solo mide tiempo; no verifica suscripciones.
