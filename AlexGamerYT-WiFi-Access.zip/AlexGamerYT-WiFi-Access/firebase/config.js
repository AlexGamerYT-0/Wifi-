// Pega aquí la configuración de tu app web de Firebase (Configuración del proyecto > Tus apps).
// Es pública por diseño: la seguridad la dan las reglas de firestore.rules.
window.FIREBASE_CONFIG = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  appId: "TU_APP_ID"
};
