const $=s=>document.querySelector(s);
let cfg={ssid:"iPhone de Alex",password:"pepe1234",youtube:"https://youtube.com/@alexgameryt-0",seconds:5},db=null,visit=null,name="",shown=false;
try{if(FIREBASE_CONFIG.apiKey!=="TU_API_KEY"){firebase.initializeApp(FIREBASE_CONFIG);db=firebase.firestore();
 db.doc("settings/main").get().then(d=>{if(d.exists)cfg={...cfg,...d.data()}}).catch(()=>{})}}catch(e){console.warn(e)}
const show=id=>{["s1","s2","s3"].forEach(s=>$("#"+s).classList.toggle("hide",s!==id))};
$("#go1").onclick=async()=>{name=$("#name").value.trim().slice(0,40);if(!name){$("#name").focus();return}
 if(db)try{visit=await db.collection("visits").add({name,createdAt:firebase.firestore.FieldValue.serverTimestamp(),youtube:false,completed:false})}catch(e){console.warn(e)}
 show("s2")};
$("#name").onkeydown=e=>{if(e.key==="Enter")$("#go1").click()};
const upd=o=>{if(db&&visit)visit.update(o).catch(()=>{})};
$("#yt").onclick=()=>{window.open(cfg.youtube,"_blank","noopener");upd({youtube:true});
 let t=Number(cfg.seconds)||5,tot=t;$("#bar").classList.remove("hide");$("#yt").disabled=true;
 const tick=()=>{$("#fill").style.width=((tot-t)/tot*100)+"%";$("#msg").textContent=t>0?`Espera ${t} s…`:"¡Listo! Ya puedes continuar.";
  if(t<=0){$("#go2").disabled=false;$("#go2").classList.remove("sec");return}t--;setTimeout(tick,1000)};tick()};
$("#go2").onclick=()=>{upd({completed:true});$("#who").textContent=name;$("#ssid").textContent=cfg.ssid;show("s3")};
$("#eye").onclick=()=>{shown=!shown;$("#pw").textContent=shown?cfg.password:"••••••••";$("#eye").textContent=shown?"Ocultar":"Mostrar"};
$("#copy").onclick=async()=>{try{await navigator.clipboard.writeText(cfg.password)}catch{const i=document.createElement("input");i.value=cfg.password;document.body.appendChild(i);i.select();document.execCommand("copy");i.remove()}$("#copy").textContent="¡Copiada!";setTimeout(()=>$("#copy").textContent="Copiar contraseña",2000)};
if(/Android/i.test(navigator.userAgent))$("#wset").classList.remove("hide");
